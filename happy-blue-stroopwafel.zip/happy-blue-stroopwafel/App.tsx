import { StyleSheet, Text, View, FlatList, Pressable } from 'react-native';
import {useState} from "react"

interface Item {
  id: string
  ten: string
  gia: string
}
interface Cart {
  ten: string
  soLuong: number
}


export default function App() {
  const [carts, setCarts] = useState([])

  const handAddProduct = (item) => {
    setCarts(item)
  }

  const products = [{id: "1",ten: "Sản phẩm 1", gia: "20000"},
{id: "2",ten: "Sản phẩm 2", gia: "20000"},
{id: "3",ten: "Sản phẩm 3", gia: "20000"},
{id: "4",ten: "Sản phẩm 4", gia: "20000"},
{id: "5",ten: "Sản phẩm 5", gia: "20000"},
{id: "6",ten: "Sản phẩm 6", gia: "20000"}]

  const renderProductItem = ({item}: Item) => (
    <View style={styles.itemcontainer}>
      <View>
        <Text>{item.ten}</Text>
        <Text>{item.gia}</Text>
      </View>
      <View>
        <Pressable style={styles.button} onPress={() => handAddProduct(item)}>Thêm giỏ hàng</Pressable>
      </View>
    </View>
  )

  const renderCart = ({cart}: Cart) => (
    <View>
      <Text>{cart.ten}: {cart.soLuong}</Text>
    </View>
  )
  return (
   
     
     <View>
     <FlatList data={products} renderItem={renderProductItem} keyExtractor={item => item.id}/>
     <View>
      <Text>Giỏ hàng</Text>
        <FlatList data={carts} renderItem={renderCart}/>
     </View>
     </View>
   
  );
}

const styles = StyleSheet.create({
  itemcontainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#ecf0f1',
    padding: 10,
    borderWidth: 1,
    borderColor: "black",
    marginTop: 10
   
  },
  button: {
    borderColor: "black",
    padding: 5,
    borderRadius: 5,
    backgroundColor: "blue",
    color: "white"
    
  }
});
